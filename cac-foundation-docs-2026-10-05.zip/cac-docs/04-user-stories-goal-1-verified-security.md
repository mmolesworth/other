# Work items: Goal 1, Verified security

Sixteen items cover the five objectives: nine user stories, six tasks, one spike. Each objective is a Feature under the Epic "Goal 1: Verified security". Roles used: ISSO, OCIO system owner, security team analyst, Salesforce administrator. Demand Type is set to "Security" throughout; replace with the value from the field's list.

**Azure DevOps:** Agile process template. Hierarchy Epic > Feature > User Story / Bug > Task. Acceptance Criteria go in the dedicated field, as one contiguous block, not in the Description.

---

## Feature 1.1: Security posture against the in-scope NIST 800-53 controls

### Collect review evidence

**Type:** Task · **Parent Feature:** 1.1 Security posture · **Demand Type:** Security · **ServiceNow ID:** none

**Work.** Pull and store the Setup artifacts the review scores against: Health Check report and score, Optimizer report, Setup Audit Trail export (180 days), Login History export (6 months), installed packages list, Connected Apps with OAuth usage, profile and permission set exports, Session Settings and password policy pages. Store them in the evidence location in the repository and link each to the findings-log rows it supports.

**Completion condition.** Every practice in domains 1 to 8 of the findings log that depends on a Setup artifact has at least one evidence link that opens.

### Schedule the review sessions

**Type:** Task · **Parent Feature:** 1.1 Security posture · **Demand Type:** Security · **ServiceNow ID:** none

**Work.** Book four 90-minute sessions covering domains 1 to 8 with the ISSO, the Salesforce administrator, and the developer; invite OCFP to the data protection session (domain 3). Distribute the question list and the status definitions a week ahead.

**Completion condition.** Four sessions are on calendars with the named attendees accepted, and the question list has been sent.

### Rate every security best practice with evidence

**Type:** User Story · **Parent Feature:** 1.1 Security posture · **Demand Type:** Security · **ServiceNow ID:** none

**Description**

As the ISSO,
I want each security best practice in the review rated with the evidence behind the rating,
So that I can tell which controls are in place from the record rather than from the team's word.

**Acceptance Criteria**

- Every practice in domains 1 to 8 of the findings log (93 rows) has a Status of Implemented, Partial, Not implemented, or Not applicable; no row remains Not yet reviewed.
- Every row with a Status other than Not applicable has an Evidence entry naming a file, export, or Setup page a reviewer can open.
- Every row with Status Partial or Not implemented has a Finding severity of High, Medium, or Low and a named Owner.
- Every Not applicable row has a Note stating why it does not apply to the CAC.
- The Summary sheet's counts by domain, status, and severity match the Findings log with no manual entry.
- Domain 9 rows stay Not yet reviewed and are listed as next-cycle scope.

**Assumptions**

- Sessions run at ten minutes per question, as the findings log's instructions state; design discussions go to the Note column.

**Open Questions**

- Are the PT (PII Processing and Transparency) controls in scope? The mapping document leaves this pending client guidance.

### Report the status of each in-scope NIST control

**Type:** User Story · **Parent Feature:** 1.1 Security posture · **Demand Type:** Security · **ServiceNow ID:** none

**Description**

As the OCIO system owner,
I want a status for each in-scope NIST 800-53 control,
So that I can see which controls are in place, partly in place, or missing, and where the evidence for each one lives.

**Acceptance Criteria**

- The report lists every base control in the eight in-scope families (AC, AU, CM, CP, IA, IR, SC, SI), 96 controls per the mapping document.
- Each control shows exactly one status: In place, Partly in place, Not in place, Inherited from Salesforce Government Cloud, or Agency-owned.
- Each In place, Partly in place, or Not in place control lists the review practices and evidence that support its status.
- Each Inherited control cites the Customer Responsibility Matrix entry that assigns it to Salesforce.
- Each Partly in place or Not in place control names an owner and links to its rows in the ranked list.
- The report is readable by someone without Salesforce access.

**Assumptions**

- A control is In place only when every practice mapped to it is Implemented or Not applicable; Not in place when any mapped practice is Not implemented; otherwise Partly in place.

**Open Questions**

- Is the Customer Responsibility Matrix for Salesforce Government Cloud available to the team? Without it, Inherited statuses stay provisional.

### Maintain one ranked list of security weaknesses

**Type:** User Story · **Parent Feature:** 1.1 Security posture · **Demand Type:** Security · **ServiceNow ID:** none

**Description**

As the ISSO,
I want every security finding from the review, the agency scanner, and the code analyzer in one ranked list with an owner and a disposition,
So that nothing is unassigned and the highest risks are worked first.

**Acceptance Criteria**

- Every finding from the three sources appears once; duplicates are merged and keep every source reference.
- Each row shows source, finding, severity (High, Medium, Low), owner, disposition, status, and date recorded.
- Disposition is one of: Remediate, Accept, Defer to modernization, False positive.
- A False positive row cites a primary source (Salesforce documentation or the Customer Responsibility Matrix).
- An Accept row names the accepting authority and the acceptance date.
- Rows mapped to a NIST control carry the control ID.
- The list sorts by severity, then by date recorded.
- A row cannot be closed without a disposition and an approver recorded.

**Open Questions**

- Who has authority to Accept a finding: the ISSO alone, or the ISSO with the OCIO system owner for High severity?

---

## Feature 1.2: Who has access and at what level

### List every account with its access and justification

**Type:** User Story · **Parent Feature:** 1.2 Access justified · **Demand Type:** Security · **ServiceNow ID:** none

**Description**

As the ISSO,
I want a list of every active account with its access level and the reason it exists,
So that I can confirm only authorized people and systems can reach the CAC.

**Acceptance Criteria**

- Every active user account appears with username, the person or system it belongs to, profile, permission sets, last login date, business justification, and approving owner.
- Accounts holding administrator-level permissions (Modify All Data, View All Data, Manage Users, Author Apex) are flagged.
- Integration and API-only accounts are marked as such and name the integration each serves.
- Guest and site user profiles are listed with their object and field permissions.
- An account with no identifiable owner or justification is flagged Unjustified.
- Counts of total active, administrator-level, integration, and Unjustified accounts are shown and can be reproduced from a fresh export.
- Inactive and frozen accounts are out of scope except for a count.

### Remove access that cannot be justified

**Type:** User Story · **Parent Feature:** 1.2 Access justified · **Demand Type:** Security · **ServiceNow ID:** none

**Description**

As the ISSO,
I want accounts that cannot be justified disabled and integrations moved off personal logins,
So that no unexplained access to the CAC remains.

**Acceptance Criteria**

- Each account flagged Unjustified is either justified with a named owner or deactivated within [N] business days of the list being issued.
- No active integration authenticates with a named person's credentials; each runs under a dedicated integration account.
- Each deactivation is recorded with date, actor, and reason.
- Records owned by a deactivated account are reassigned to [owner or queue] before deactivation.
- Administrator-level permissions are held only by the named set, and the count is stated.
- If a deactivation stops an integration or scheduled job, the account is restored the same day and the event is recorded.

**Open Questions**

- What is the window for justifying or deactivating a flagged account?
- Who approves a deactivation?
- Where do records owned by deactivated accounts go?

---

## Feature 1.3: Code vulnerabilities resolved before release

### Run the first code analysis against the baseline

**Type:** Task · **Parent Feature:** 1.3 Code vulnerabilities · **Demand Type:** Security · **ServiceNow ID:** none

**Work.** Run the Salesforce Code Analyzer with the recommended rule set across the metadata baseline. Save the report in the repository and summarize findings by severity and engine.

**Completion condition.** The report is in the repository, and every High finding is entered in the ranked list with an owner.

### Determine whether the analyzer sees JavaScript inside static resources

**Type:** Spike · **Parent Feature:** 1.3 Code vulnerabilities · **Demand Type:** Security · **ServiceNow ID:** none

**Question.** Does the Code Analyzer's outdated-library check detect jQuery versions bundled inside zipped static resources and referenced from Visualforce pages, and what configuration does it need?

**Time box.** 4 hours.

**Artifact.** A note in the repository stating what is and is not detected, the configuration used, and the gap the scanner must still cover.

### Make code analysis a gate in the pipeline

**Type:** Task · **Parent Feature:** 1.3 Code vulnerabilities · **Demand Type:** Security · **ServiceNow ID:** none

**Work.** Add a Code Analyzer step to the pipeline that runs on every change, fails the run on any High finding, and publishes the report as a build artifact. Record any baseline suppressions with a reason.

**Completion condition.** A commit containing a known High finding fails the pipeline; the same commit with the finding fixed passes; the report is attached to both runs.

### Remove the outdated jQuery versions

**Type:** User Story · **Parent Feature:** 1.3 Code vulnerabilities · **Demand Type:** Security · **ServiceNow ID:** none

**Description**

As the ISSO,
I want the outdated jQuery versions removed from the CAC,
So that the known-vulnerable library is no longer in production.

**Acceptance Criteria**

- No static resource, Visualforce page, or Lightning component in production references a jQuery version earlier than [required version].
- The agency scanner's jQuery findings show closed on the first scan after the deployment.
- The business test cases for every page that loads jQuery pass before and after the deployment.
- The analyzer's outdated-library check reports no jQuery finding on the deployed commit.
- Any page that cannot be upgraded is listed in the ranked list with a disposition.

**Open Questions**

- Which jQuery version does the scanner require as the minimum?
- Which pages load jQuery? The earlier trace through Visualforce and static resources is the starting list.

### Close the HTTPOnly cookie findings with a defensible decision

**Type:** User Story · **Parent Feature:** 1.3 Code vulnerabilities · **Demand Type:** Security · **ServiceNow ID:** none

**Description**

As the ISSO,
I want each HTTPOnly cookie finding closed with a decision I can defend,
So that the same finding stops reappearing on every scan.

**Acceptance Criteria**

- Every HTTPOnly finding is listed with the cookie name, who sets it (Salesforce platform, platform-managed JavaScript, or custom code), and a disposition.
- A cookie set by the platform or by platform-managed JavaScript is dispositioned False positive with the Salesforce Platform Security FAQ cited.
- A cookie set by custom code is remediated, or accepted with a reason and an accepting authority.
- A finding re-reported for a dispositioned cookie is closed by reference to the earlier disposition, with no new investigation.

**Open Questions**

- The full list of cookie names from the scan report.

---

## Feature 1.4: Access management process

### Record every access grant, change, and removal

**Type:** User Story · **Parent Feature:** 1.4 Access process · **Demand Type:** Security · **ServiceNow ID:** none

**Description**

As the ISSO,
I want every grant, change, and removal of CAC access to follow one recorded process,
So that I can show who requested and who approved each change in access.

**Acceptance Criteria**

- A written procedure covers request, approval, provisioning, change, and removal, and names the approver role for each step.
- Every account created or changed after the procedure's start date has a request record with requester, approver, date, and access granted.
- A leaver's access is removed within [N] business days of notification.
- A mover's permissions are adjusted within [N] business days of the role change.
- Every user and permission change in the Setup Audit Trail during the period matches a request record.
- Emergency access is defined: who may use it, how it is logged, and who reviews each use afterward.
- Changes to the agency identity provider are out of scope.

**Open Questions**

- Who requests access on OCFP's side, and who approves?
- Is ServiceNow the request channel, or something else?
- What are the removal and adjustment windows?

### Review user permissions on a schedule

**Type:** User Story · **Parent Feature:** 1.4 Access process · **Demand Type:** Security · **ServiceNow ID:** none

**Description**

As the ISSO,
I want user permissions reviewed on a schedule with a record of what was found and changed,
So that excess access is caught on a cadence rather than after an incident.

**Acceptance Criteria**

- A review schedule is set with a named reviewer.
- The first review is completed in the period, and its record lists accounts reviewed, exceptions found, changes made, reviewer, and date.
- The review covers administrator-level permissions explicitly.
- Each exception has a resolution within [N] days or an accepted-risk entry with an approver.
- The review record is retrievable from the governance evidence location.

**Open Questions**

- Review frequency: quarterly is the usual starting point; confirm with the ISSO.

### Write the access control section of the governance plan

**Type:** Task · **Parent Feature:** 1.4 Access process · **Demand Type:** Security · **ServiceNow ID:** none

**Work.** Draft section 4 (Access control) of the governance plan per the outline: least privilege through permission sets, MFA enforcement, login IP ranges and session settings, integration accounts, administrator governance, joiner-mover-leaver, periodic review. Add the controls catalog rows (section 10) for each, and write or reference the user provisioning and access review runbooks.

**Completion condition.** Section 4 is drafted, every control in it has a catalog row with statement, verification method, frequency, evidence location, owner, and NIST family, and each referenced runbook is marked exists or needed.

---

## Feature 1.5: Vulnerability disposition process

### Show the security team the status of every finding they reported

**Type:** User Story · **Parent Feature:** 1.5 Vulnerability process · **Demand Type:** Security · **ServiceNow ID:** none

**Description**

As a security team analyst,
I want to see the status of every finding I reported without asking the team,
So that I know what has been fixed, accepted, or dismissed and why.

**Acceptance Criteria**

- Every finding the security team has reported appears in the register with received date, source scan, severity, owner, triage date, disposition, status, and evidence or citation.
- Status is one of: New, Triaged, In remediation, Remediated, Accepted, False positive, Deferred.
- An owner and a proposed disposition are recorded within [N] business days of receipt.
- A False positive disposition cites a primary source.
- A re-reported finding that matches a dispositioned one is closed by reference within [N] business days, with no new investigation opened.
- A finding with no owner after the triage window is escalated to [role].
- The security team opens the register with their own access; no request to the team is needed.

**Open Questions**

- The triage window.
- Who receives the escalation.
- Where the register lives so the security team can reach it (repository, SharePoint, ServiceNow).

### Write the vulnerability management section of the governance plan

**Type:** Task · **Parent Feature:** 1.5 Vulnerability process · **Demand Type:** Security · **ServiceNow ID:** none

**Work.** Draft the vulnerability management part of section 5 (Security configuration and monitoring) per the outline: scanner cadence, triage process, disposition categories, citation standard, and the code analyzer as a release control. Add the controls catalog rows and write or reference the scanner triage runbook.

**Completion condition.** The section is drafted, each control has a catalog row with statement, verification method, frequency, evidence location, owner, and NIST family, and the scanner triage runbook is marked exists or needed.

---

## Still to write

Work items for Goals 2, 3, and 4 have not been written. The sprint matrix in `02-sprint-plan-matrix.md` holds the activity statements they would be derived from.
