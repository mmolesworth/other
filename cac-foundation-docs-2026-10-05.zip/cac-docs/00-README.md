# CAC Foundation: strategy and plan documents

**Package date:** 2026-10-05
**Planning period:** October 8 to December 16, 2026 (five two-week sprints)
**Source:** working session of 2026-10-02, Salesforce project

## Contents

| File | What it holds |
|---|---|
| `01-strategy-goals-objectives-outcomes.md` | The strategy (diagnosis and guiding policy), four goals, fifteen objectives, and the outcomes under each objective |
| `02-sprint-plan-matrix.md` | Sprints down, goals across; one activity statement per cell |
| `03-roadmap-overview.md` | How the work is organized, the 13 added activities and their disposition, gates and calendar, assumptions and open items |
| `04-user-stories-goal-1-verified-security.md` | Sixteen Azure DevOps work items for Goal 1: nine user stories, six tasks, one spike |
| `05-decisions-and-open-items.md` | Decisions taken in the session, open questions, and what is not yet done |

## How these fit together

The strategy sets the challenge and the approach. The four goals state the end states it aims at. Each goal carries objectives (commitments for this period) and outcomes (the behavior each objective changes). The sprint matrix allocates the work across five sprints. The user stories are the Azure DevOps items that deliver one goal's objectives.

The roadmap overview predates the four-goal structure. It still uses the two June goals (See the System, Control the Change) and the workstream names Baseline, Review, Tests, Governance. It is included for the activity dispositions, the calendar, and the assumptions, which remain current.

## Related project documents not in this package

- `cac-governance-plan-outline.md` — the governance plan structure; the vehicle for several objectives
- `cac-well-architected-review-questions.md` and `cac-war-findings-log.xlsx` — the review framework and its findings log
- `nist-800-53-to-war-mapping.md` — the eight in-scope control families mapped to review practices
- `2026_06_09 Building the Foundation for Safe Predictable Change.pptx` — the June presentation the strategy was drawn from
