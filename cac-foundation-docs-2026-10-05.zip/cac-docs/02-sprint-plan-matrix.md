# Sprint plan by goal

Five two-week sprints, October 8 to December 16, 2026. Each cell holds the work that sprint does toward that goal.

| Sprint | 1. Verified security | 2. One picture of the system | 3. Controlled change, delivered | 4. Recoverable |
|---|---|---|---|---|
| **Sprint 1** (10/8 to 10/21) | Gather evidence, list accounts, scan the code. | Commit metadata, record certificates, start the mapping. | Pipeline to QA, draft the first test cases. | Install the app, create the service account, connect production. |
| **Sprint 2** (10/22 to 11/4) | Run the review, rank the weaknesses. | Map the first nine objects, draw the diagrams. | Pipeline to production, ship the first change. | Turn on backups, set failure alerts. |
| **Sprint 3** (11/5 to 11/18) | Fix the high ones, tighten admin access. | Classify all 55 objects, verify the diagrams. | Ship the modification request, recommend address options. | Restore sample data, write the steps. |
| **Sprint 4** (11/19 to 12/2) | Review access, write the security processes. | Finish the mapping, spot-check it. | Extend the test suite, measure turnaround. | Repeat the restore, tune the schedule. |
| **Sprint 5** (12/3 to 12/16) | Decide every remaining weakness. | Submit the obsolete list, refresh the record. | Record turnaround, set the release gate. | — |

## Notes on the cells

**Goal 4, Sprint 5 is deliberately empty.** The remaining recovery work (recovery targets, restore-test cadence) goes into the governance plan rather than being executed in this period.

**Goal 4 activities** were derived from the Salesforce Backup & Recover documentation: setup and permissions, services and backup types, scheduling, retention and exclusions, the restore application, Smart Alerts, the weekly report, and Compare and Find.

- Sprint 1 covers install, the dedicated service account with the required permissions, and connecting production. Licensing and security approval are the client's to supply.
- Sprint 2 covers the schedule, retention, exclusions, the first on-demand backup checked against the object register, and alerts routed to a named owner.
- Sprint 3 covers the restore application, restore order from the process map, automation suppression steps, the exercise itself, and verification with Compare and Find.
- Sprint 4 covers a second team member repeating the restore from the written steps, plus tuning the schedule from the first month's history.

**Open check before Sprint 3:** confirm with the vendor that a cross-org restore into a sandbox is supported under the agency's license. The documentation treats restore as returning data to the org it came from. If it is not supported, the exercise target changes to a sandbox backup service.

## Dependencies across columns

- Goal 1's analyzer gate (Sprint 2) depends on Goal 3's pipeline QA path (Sprint 1).
- Goal 4's restore order (Sprint 3) depends on Goal 2's diagrams and process map.
- Goal 1's review of data-protection controls (Sprint 2) and Goal 3's address recommendation (Sprint 3) both draw on Goal 2's field baseline.
- Goal 1 Sprints 2, 3, and 5 need the ISSO present for sessions and dispositions.

## Calendar constraints

| Sprint | Dates | Working days | Federal holiday |
|---|---|---|---|
| 1 | Thu 10/8 to Wed 10/21 | 9 | Columbus Day, Mon 10/12 |
| 2 | Thu 10/22 to Wed 11/4 | 10 | None |
| 3 | Thu 11/5 to Wed 11/18 | 9 | Veterans Day, Wed 11/11 |
| 4 | Thu 11/19 to Wed 12/2 | 8 | Thanksgiving, Thu 11/26 (Fri 11/27 assumed off) |
| 5 | Thu 12/3 to Wed 12/16 | 10 | None |

One week of planned absence (dates to be set) falls inside the window; the sprint that absorbs it carries no gate.
