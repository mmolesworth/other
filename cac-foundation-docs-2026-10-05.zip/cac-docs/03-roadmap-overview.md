# CAC Foundation Roadmap: overview

**As of:** 2026-10-02 · Mark

Five two-week sprints, Thursday 10/8/2026 through Wednesday 12/16/2026, deliver the four foundation pieces from the June presentation (component inventory under source control, well-architected review, business-driven test cases, revised O&M plan) and push the first controlled changes to production through them. Nine of the 13 added activities land inside the window; data architecture, international address, Google Analytics, and the OCC/CFPB API are decided or scoped here and built in the cycle after.

> **Note on vocabulary.** This overview was written before the four-goal structure in `01-strategy-goals-objectives-outcomes.md`. It uses the two June goals (See the System, Control the Change) and the workstream names Baseline, Review, Tests, Governance. The activity dispositions, the calendar, and the assumptions below remain current.

## How the work is organized

The two June goals are the spine. The four deliverables are the workstreams, the pipeline and OWN are the mechanisms Control the Change runs on, and each added activity either feeds a workstream or goes through the foundation as one of its first controlled changes.

| Goal | Workstream | Produces by 12/16 | Absorbs |
|---|---|---|---|
| See the System | 1. Baseline: object and field mapping, requirements, and operating record under source control | One repository: production metadata baseline, component inventory tied to business processes, data profile by object with PII flags, requirements specification as text, operating record (environments, certificates, licenses) | #5 current-state data architecture, #7 certificate register, #13 C4 diagrams as code |
| See the System | 2. Review: well-architected review, security first | Domains 1 to 8 (93 of 106 practices) scored with evidence; one ranked gap list merging review, scanner, and analyzer findings, each with a disposition | #4 jQuery and HTTPOnly dispositions, #11 analyzer triage, #6 address decision, #5 target data architecture |
| Control the Change | 3. Tests: business-driven test cases and test data | Test cases for the processes the first changes touch; scrubbed sandbox data; the suite runs as the deployment gate | #12 sandbox email replacement |
| Control the Change | 4. Governance: revised O&M plan | Governance plan v1 per the September outline, controls catalog included; it describes what the pipeline, OWN, and the refresh process now do | None directly |
| Control the Change | Mechanisms: pipeline and backup | Every production change goes through the pipeline; OWN live with a restore exercised and documented | #2 CI/CD pipeline, #1 OWN backup |
| Control the Change | First controlled changes | Changes delivered through the pipeline, gated by tests, smallest first | #9 email fix, #3 modification request, #4 jQuery remediation, #11 High findings; #8 and #10 scoped only |

## The 13 added activities

Nine are delivered and four are decided or scoped. Nothing is dropped: what does not fit is scoped well enough here to size it for the next cycle.

| # | Activity | Disposition | Workstream | Sprint | Note |
|---|---|---|---|---|---|
| 1 | OWN backup solution | Decide or scope in window | Mechanism | 1 to 3 | Design decisions in S1, live in S2, restore exercised and documented in S3. The restore is the gate for any later removal of components or data. |
| 2 | CI/CD pipeline for deployments | Deliver in window | Mechanism | 1 to 2 | QA path in S1, production path in S2. The code analyzer is added as a pipeline gate in S3. |
| 3 | Modification request (required fields, modified footer) | Deliver in window | First controlled changes | 2 to 3 | First business change through the full path: requirement in the repository, test cases, pipeline, production. |
| 4 | jQuery references and HTTPOnly attribute | Deliver in window | Review, then changes | 2 to 3 | jQuery upgrade deployed in S3 once tests cover the Visualforce pages it touches. HTTPOnly on JavaScript-set cookies is a documented false positive; the gap list records the disposition. |
| 5 | Data architecture: current, target, migration plan | Decide or scope in window | Baseline, Review | 1 to 5 | Current state from the inventory and data profile (S2). Target model and migration approach as a decision paper (S3 to S5). No remodeling in the window. |
| 6 | International address support | Decide or scope in window | Review | 3 | Decision between ISO 3166 picklists on Case and Contact MailingAddress, taken with the target data architecture. Build follows. |
| 7 | SSL certificate register | Deliver in window | Baseline | 1 | Certificates, expirations, owners, where each is used. Part of the operating record. |
| 8 | Google Analytics integration | Decide or scope in window | First controlled changes | 3 | Scope only: what is measured, on which pages, and the cookie consequences for the HTTPOnly finding. Built next cycle unless it proves to be a small change. |
| 9 | Invalid external email address | Deliver in window | First controlled changes | 1 to 2 | First change through the pipeline: small, isolated, incident-adjacent. If it is a Setup setting rather than metadata, it becomes a change record and #3 goes first. |
| 10 | OCC and CFPB API integration | Decide or scope in window | Baseline, Review | 2 to 3 | CFPB ingestion exists (architecture document 7.8); OCC is new (7.9). In window: document the CFPB interface in the C4 diagrams and review it under domain 2; capture OCC requirements and the interface contract. Build, interconnection agreement, and boundary review follow. |
| 11 | Static code analyzer findings | Deliver in window | Review, then changes | 1 to 5 | Run in S1 as review evidence, triaged into the gap list in S2, High findings fixed in S3 to S5, analyzer runs as a pipeline gate from S3. Remaining findings go to the next cycle. |
| 12 | Standard email address in lower environments | Deliver in window | Tests | 2 | Scripted as a post-refresh step, not a one-time fix: every refresh copies production addresses back. Second layer behind the platform's system-email-only default on refresh. |
| 13 | C4 architecture diagrams | Deliver in window | Baseline | 2 to 5 | Context and container diagrams in S2, component diagram for the areas changed in S3, refreshed in S5. Written as diagram-as-code so they live in the repository. |

## Gates and calendar

Six ordering rules hold the plan together. Each one is a gate on the timeline.

1. Pipeline deploying to QA (end of Sprint 1) before any change is built.
2. #9 in production through the pipeline (Sprint 2) before #3 or #4: the production path is proven on something small first.
3. Test cases committed before a business-visible change (#3, #4) reaches production.
4. Sandbox emails replaced (#12) before any test run that fires email alerts.
5. Review findings (Sprint 2) before the architecture decisions (#5 target, #6) in Sprint 3.
6. Restore exercised (Sprint 3) before any destructive change. None is scheduled in this window, which is deliberate.

| Sprint | Dates | Working days | Federal holiday | Client input needed |
|---|---|---|---|---|
| 1 | Thu 10/8 to Wed 10/21 | 9 | Columbus Day, Mon 10/12 | O&M plan template constraint (OCIO); OWN license and ATO package status |
| 2 | Thu 10/22 to Wed 11/4 | 10 | None | Review session attendance (ISSO, admin, OCFP for domain 3); OWN enablement |
| 3 | Thu 11/5 to Wed 11/18 | 9 | Veterans Day, Wed 11/11 | Boundary question on the OCC API (ISSO); acceptance of #3 (OCFP) |
| 4 | Thu 11/19 to Wed 12/2 | 8 | Thanksgiving, Thu 11/26 (Fri 11/27 assumed off) | Decision paper review (OCFP) |
| 5 | Thu 12/3 to Wed 12/16 | 10 | None | Closing readout (OCIO) |

One week of planned absence (dates to be set) falls inside the window; the sprint that absorbs it carries no gate.

## Assumptions

- Two-person, part-time team, as in the September draft; no funding beyond OWN licensing.
- Production is the source of truth for the baseline.
- The OWN add-on is licensed and cleared to enable in Sprint 2. If not, OWN slides a sprint and the restore test moves to Sprint 4.
- #9 is a metadata change. If it is a Setup setting, #3 becomes the first pipeline change and the production path lands in Sprint 2 only if #3 is ready.
- The Lightning platform upgrade (the RFP in progress) does not start execution inside this window; this work prepares for it.
- The NIST 800-53 scoped assessment from the September draft is read off the review: every practice in the findings log carries its control IDs, so the control-family view is a filter on the log, not a separate activity.
- Unused component removal and archive-or-delete execution stay out of the window. Both need the restore gate (Sprint 3) and decisions from OCFP; they go to the next cycle.

## Open items

- [ ] Confirm OWN license and ATO package status. This decides whether the restore gate lands in Sprint 3.
- [ ] Confirm #9 is metadata and deployable.
- [ ] Confirm whether the O&M plan must follow an agency or contract template.
- [ ] Name an owner per workstream and per section of the governance outline.
- [ ] Book the four review sessions and the OCFP decision paper review before Sprint 1 ends.
- [ ] Effort estimates per activity and a client-facing version. Same gap as the September draft.
