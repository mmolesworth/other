# Decisions and open items

**Recorded:** 2026-10-02, updated 2026-10-05

## Decisions taken

### Strategy

- The strategy was extracted from the June 2026 presentation "Building the Foundation for Safe Predictable Change" rather than written fresh. The deck's Complication supplied the diagnosis; "fix only what cannot wait and defer what we will rebuild anyway" supplied the guiding policy.
- The strategy is kept to diagnosis and guiding policy. Trade-offs, source of advantage, major moves, assumptions, and stakeholder response were drafted and then dropped for this exercise. They remain available if a fuller version is needed for OCIO.
- The deferral rule was revised. The original form, "build now only what cannot wait," was a default-defer rule that would have made every OCFP request an argument. It now reads: build on today's system whatever the upgrade will not redo; fold the rest into the upgrade.

### Goals

- The two June goals (See the System, Control the Change) were replaced by four. Both originals failed the end-state test, being verb phrases naming an activity.
- Controlled change and continued delivery of OCFP's requests were combined into one goal, at Mark's direction. The argument against combining was decidability: the two halves can fail independently. The argument for was that the controlled path is the means by which OCFP's changes are delivered, so they are one idea.
- Recovery was given its own goal rather than being folded into controlled change. It is one of the three imminent initiatives in the June deck, and a hidden goal is the one that gets dropped when a sprint is tight.
- Security was given its own goal and then promoted to Goal 1. The wording avoids "the system is secure," which is a platitude; the real choice is verified versus asserted.
- Final order: 1 Verified security, 2 One picture of the system, 3 Controlled change delivered, 4 Recoverable.

### Objectives and outcomes

- Objectives inherit the end of the planning period. A date appears only where one differs, such as an external deadline or a dependency.
- Dates that depend on OCFP or on OWN enablement were removed, since the owner cannot control them.
- Goal 1 carries five objectives, one over the two-to-four guideline. This is intentional.
- Outcomes are written as the behaviors each objective enables, not as completion measures. An earlier pass wrote completion measures and they collapsed into the objective restated with a number.
- Metrics, baselines, and guardrails were deliberately left out of this pass. The per-goal table (Objective, Owner, Outcome, Metric, Baseline, Target, Target date, Data source, Guardrail) is not yet built.

### Scope

- "In-scope NIST 800-53 controls" means eight families: AC, AU, CM, CP, IA, IR, SC, SI. IA was added to the original seven because an assessor will expect it alongside AC for a PII exposure.
- The well-architected review is the method; NIST is the standard named in the objective. Every practice in the findings log carries its control IDs, so the control-family view is a filter on the log rather than a separate assessment.
- The governance plan (the O&M plan revision) is the vehicle for several objectives rather than an objective itself. Recovery targets and the restore-test cadence belong in it. A cross-map from objectives to governance plan sections is still to be built.
- The planning period was extended from four sprints ending 12/2 to five ending 12/16, for the holidays and a week of planned absence.

### Documents

- The five per-sprint tabs were replaced by one sprint-by-goal matrix. Matrix cells are short activity statements written for non-technical management.
- The "See the System" and "Control the Change" tabs were retired once the Strategy tab existed.

## Open questions, by owner

### OCIO

- Will the O&M plan have to follow an agency or contract template?
- Who has authority to accept a security finding: the ISSO alone, or the ISSO with the OCIO system owner for High severity?
- Is the Customer Responsibility Matrix for Salesforce Government Cloud available to the team?

### OCFP

- Who requests access on OCFP's side, and who approves?
- Recovery point and recovery time targets, for the governance plan.

### ISSO / security team

- Are the PT (PII Processing and Transparency) controls in scope for this cycle?
- What is the triage window for a reported vulnerability, and who receives an escalation when a finding has no owner?
- Where does the vulnerability register live so the security team can reach it?
- What is the permission review frequency?
- Which jQuery version is the scanner's minimum?

### Vendor / licensing

- Is the OWN add-on licensed and cleared to enable in Sprint 2?
- Is a cross-org restore into a sandbox supported under the agency's license?

### Team

- Is #9 (the invalid external email address) a metadata change or a Setup setting? This decides which change proves the pipeline first.
- What are the removal and adjustment windows for leavers and movers?
- What is the Demand Type field's value list in Azure DevOps?

## Not yet done

- Owners other than Mark on any objective.
- Metrics, baselines, targets, data sources, and guardrails for the outcomes.
- The final per-goal table called for in the planning framework.
- Work items for Goals 2, 3, and 4.
- Cross-map from objectives to governance plan sections.
- Effort estimates per activity and a client-facing version of the roadmap.
